<?php

namespace Drupal\md_count\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Url;

/**
 * Class DisplayTableController.
 *
 * @package Drupal\md_count\Controller
 */
class DisplayTableController extends ControllerBase {

  /**
   * Display count records in a table.
   *
   * @return array
   *   Return table render array.
   */
  public function display() {
    // Create table header.
    $header_table = [
      'id' => $this->t('ID'),
      'service' => $this->t('Service'),
      'value' => $this->t('Value'),
      'operations' => $this->t('Operations'),
    ];

    // Select records from table.
    $query = \Drupal::database()->select('md_count', 'm');
    $query->fields('m', ['id', 'service', 'value']);
    $query->orderBy('id', 'DESC');
    $results = $query->execute()->fetchAll();
    
    $rows = [];
    foreach ($results as $data) {
      $delete_url = Url::fromRoute('md_count.delete_form', ['cid' => $data->id]);
      $edit_url = Url::fromRoute('md_count.Update_Form', ['cid' => $data->id]);

      // Build row with operations.
      $rows[] = [
        'id' => $data->id,
        'service' => $data->service,
        'value' => $data->value,
        'operations' => [
          'data' => [
            '#type' => 'operations',
            '#links' => [
              'edit' => [
                'title' => $this->t('Edit'),
                'url' => $edit_url,
              ],
              'delete' => [
                'title' => $this->t('Delete'),
                'url' => $delete_url,
              ],
            ],
          ],
        ],
      ];
    }

    // Display data in table.
    $form['table'] = [
      '#type' => 'table',
      '#header' => $header_table,
      '#rows' => $rows,
      '#empty' => $this->t('No counts found'),
    ];

    return $form;
  }

}
