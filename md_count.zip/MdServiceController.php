<?php

namespace Drupal\md_count\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class MdServiceController.
 *
 * @package Drupal\md_count\Controller
 */
class MdServiceController extends ControllerBase {

  /**
   * Display information.
   *
   * @return array
   *   Render array.
   */
  public function display() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('This page contains all information about count service.'),
    ];
  }

}
