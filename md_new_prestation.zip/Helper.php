<?php

namespace Drupal\md_new_prestation\Helper;

use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\webform\Entity\WebformSubmission;

require_once '/home/auejsb/public_html/vendor/autoload.php';

use Twilio\Rest\Client;

/**
 * Helper class for notifications (SMS and Email).
 */
class Helper {

  use StringTranslationTrait;

  const SETTINGS = 'eprestation.settings';

  /**
   * Send an SMS notification using Twilio.
   *
   * @param string $number
   *   The phone number to send SMS to.
   *
   * @return mixed
   *   The Twilio response or null on error.
   */
  public static function sendSMS($number) {
    $sid = "AC0bcd5d9cbbd011e2b507fdc28ae89d49";
    $token = "3722ec3d0d0cd772b5e8d8cb1c750f11";
    $twilio = new Client($sid, $token);

    try {
      $result = $twilio->messages->create(
        $number,
        [
          "from" => "+12058528207",
          "body" => "L'AUEJ-SB vous informe de la validation de votre demande de paiement RSR sur sa plateforme",
        ]
      );
      return $result;
    }
    catch (\Twilio\Exceptions\RestException $e) {
      \Drupal::logger('md_new_prestation')->error("SMS failed to send: " . $e->getMessage());
      return NULL;
    }
  }

  /**
   * Send first confirmation email.
   */
  public static function sendMailFirst($email, $commune, $ndeg_dossier, $province, $nom_maitre_ouvrage, $nature_projet, $metrage_du_projet, $architecte) {
    try {
      $config = \Drupal::config('eprestation.settings');
      $search = ['[commun]', '[province]', '[nom]', '[nature]', '[metrage]', '[maitre_ouv]', '[n_rokhas]'];
      $replace = [$commune, $province, $nom_maitre_ouvrage, $nature_projet, $metrage_du_projet, $architecte, $ndeg_dossier];

      $subject = "Validation de votre demande de paiement – Autorisations d'urbanisme";

      $message_body = self::buildEmailTemplate(
        str_replace($search, $replace, $config->get('message_mail')['value'] ?? ''),
        $config->get('footer1') ?? '',
        $config->get('footer2') ?? ''
      );

      return self::sendEmail($email, $subject, $message_body, $config->get('emailcci'));
    }
    catch (\Exception $e) {
      \Drupal::logger('md_new_prestation')->error("Error in sendMailFirst: " . $e->getMessage());
      return FALSE;
    }
  }

  /**
   * Send declaration email.
   */
  public static function sendMailDeclaration($email, $commune, $ndeg_dossier, $province, $nom_maitre_ouvrage, $nature_projet, $metrage_du_projet, $architecte, $product_id) {
    try {
      $config = \Drupal::config('eprestation.settings');
      $search = ['[commun]', '[province]', '[nom]', '[nature]', '[metrage]', '[maitre_ouv]', '[n_rokhas]'];
      $replace = [$commune, $province, $nom_maitre_ouvrage, $nature_projet, $metrage_du_projet, $architecte, $ndeg_dossier];

      $subject = "Validation de votre demande de paiement – Autorisations d'urbanisme";

      $message_body = self::buildEmailTemplate(
        str_replace($search, $replace, $config->get('message_mail_final')['value'] ?? ''),
        $config->get('footer1') ?? '',
        $config->get('footer2') ?? ''
      );

      $cc_mail = $config->get('emailcci');
      return self::sendEmail($cc_mail, $subject, $message_body, $cc_mail);
    }
    catch (\Exception $e) {
      \Drupal::logger('md_new_prestation')->error("Error in sendMailDeclaration: " . $e->getMessage());
      return FALSE;
    }
  }

  /**
   * Send rejection email.
   */
  public static function sendMailRejet($email, $commune, $ndeg_dossier, $province, $nom_maitre_ouvrage, $nature_projet, $metrage_du_projet, $architecte, $product_id, $motif) {
    try {
      $config = \Drupal::config('eprestation.settings');
      $search = ['[commun]', '[province]', '[nom]', '[nature]', '[metrage]', '[maitre_ouv]', '[n_rokhas]', '[motif]'];
      $replace = [$commune, $province, $nom_maitre_ouvrage, $nature_projet, $metrage_du_projet, $architecte, $ndeg_dossier, $motif];

      $subject = "État de votre dossier N° : " . $ndeg_dossier;

      $message_body = self::buildEmailTemplate(
        str_replace($search, $replace, $config->get('message_mail_tech')['value'] ?? ''),
        $config->get('footer1') ?? '',
        $config->get('footer2') ?? ''
      );

      return self::sendEmail($email, $subject, $message_body, $config->get('emailcci'));
    }
    catch (\Exception $e) {
      \Drupal::logger('md_new_prestation')->error("Error in sendMailRejet: " . $e->getMessage());
      return FALSE;
    }
  }

  /**
   * Send facturation email.
   */
  public static function sendMailFacturation($email, $commune, $ndeg_dossier, $province, $nom_maitre_ouvrage, $nature_projet, $metrage_du_projet, $architecte, $product_id) {
    try {
      $config = \Drupal::config('eprestation.settings');
      $search = ['[commun]', '[province]', '[nom]', '[nature]', '[metrage]', '[maitre_ouv]', '[n_rokhas]'];
      $replace = [$commune, $province, $nom_maitre_ouvrage, $nature_projet, $metrage_du_projet, $architecte, $ndeg_dossier];

      $subject = "Disponibilité de votre facture pour le dossier N° " . $ndeg_dossier;

      $message_body = self::buildEmailTemplate(
        str_replace($search, $replace, $config->get('message_mail_Final_client')['value'] ?? ''),
        $config->get('footer1') ?? '',
        $config->get('footer2') ?? ''
      );

      return self::sendEmail($email, $subject, $message_body, $config->get('emailcci'));
    }
    catch (\Exception $e) {
      \Drupal::logger('md_new_prestation')->error("Error in sendMailFacturation: " . $e->getMessage());
      return FALSE;
    }
  }

  /**
   * Send email to final technician.
   */
  public static function sendMailFinalTechnicien($email, $code, $title) {
    // Implementation would go here
    return TRUE;
  }

  /**
   * Delete webform submission by field_sid.
   *
   * @param string $field_sid
   *   The submission ID to delete.
   *
   * @return int
   *   Number of deleted submissions.
   */
  public static function delete_webform_submission_by_field_sid($field_sid) {
    $query = \Drupal::entityQuery('webform_submission')
      ->condition('sid', $field_sid)
      ->accessCheck(FALSE);

    $sids = $query->execute();

    if (!empty($sids)) {
      foreach ($sids as $sid) {
        $submission = WebformSubmission::load($sid);
        if ($submission) {
          $submission->delete();
          \Drupal::logger('md_new_prestation')->notice('Deleted webform submission with ID: @sid', ['@sid' => $sid]);
        }
      }
      return count($sids);
    }

    return 0;
  }

  /**
   * Build email template.
   *
   * @param string $content
   *   The main content.
   * @param string $footer1
   *   Footer line 1.
   * @param string $footer2
   *   Footer line 2.
   *
   * @return string
   *   The complete HTML email template.
   */
  protected static function buildEmailTemplate($content, $footer1, $footer2) {
    return "
      <html lang='en'>
      <head>
        <meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
        <title>L'Agence Urbaine d'ElJadida Sidi Bennour</title>
      </head>
      <body>
        <div>
          <table style='width:525pt;' cellspacing='0' cellpadding='0' border='0' width='875'>
            <tbody>
              <tr style='height:30pt;' height='50'>
                <td valign='top'>
                  <div style='margin:0;'>
                    <img src='https://auejsb.ma/sites/default/files/logo-auto.png' >
                  </div>
                </td>
                <td></td>
                <td></td>
              </tr>
              <tr style='height:3.75pt;' height='6'>
                <td colspan='3' style='height:3.75pt;background-color:#D8512D;padding:0;'>
                  <span style='background-color:#D8512D;'></span>
                </td>
              </tr>
              <tr style='height:275.25pt;' height='458'>
                <td colspan='3' style='width:459.55pt;height:275.25pt;padding:0 3.5pt;' width='765' valign='top'>
                  <div style='margin:0;'>
                    <font size='3' face='Helvetica,sans-serif'>
                      <span style='font-size:12pt;'>
                        {$content}
                      </span>
                    </font>
                  </div>
                </td>
              </tr>
              <tr style='height:32.8pt;' height='54'>
                <td colspan='3' style='width:459.55pt;height:32.8pt;background-color:#F3F3F3;padding:0 3.5pt;' width='765' valign='top'>
                  <span style='background-color:#F3F3F3;'>
                    <div style='text-align:center;margin-right:0;margin-left:0;' align='center'>
                      <font size='3' face='Times New Roman,serif'>
                        <span style='font-size:12pt;'>
                          <font size='2' color='#666666' face='Helvetica,sans-serif'>
                            <span style='font-size:8.5pt;'>{$footer1}</span>
                          </font>
                          <font size='2' color='#666666' face='Helvetica,sans-serif'>
                            <span style='font-size:8.5pt;'>
                              <br>{$footer2}
                            </span>
                          </font>
                        </span>
                      </font>
                    </div>
                  </span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </body>
      </html>";
  }

  /**
   * Send email using mail() function.
   *
   * @param string $to
   *   Recipient email address.
   * @param string $subject
   *   Email subject.
   * @param string $message
   *   Email message body.
   * @param string $cc
   *   CC email address.
   *
   * @return bool
   *   TRUE if email sent successfully.
   */
  protected static function sendEmail($to, $subject, $message, $cc = '') {
    $from_send = 'noreply@auejsb.ma';
    $headers = "From: " . $from_send . "\r\n";

    if (!empty($cc)) {
      $headers .= "Bcc: " . $cc . "\r\n";
      $headers .= "Cc: " . $cc . "\r\n";
    }

    $headers .= "Content-Type: text/html; charset=UTF-8; format=flowed\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";

    $subject = "=?UTF-8?B?" . base64_encode($subject) . "?=";

    $result = mail($to, $subject, $message, $headers);

    if (!$result) {
      \Drupal::logger('md_new_prestation')->error('Email failed to send to @email', ['@email' => $to]);
    }
    else {
      \Drupal::messenger()->addStatus(t('Your message has been sent to @email.', ['@email' => $to]));
    }

    return $result;
  }

}
