<?php

namespace Drupal\md_new_prestation\Form;

use Drupal\md_new_prestation\Helper\Helper;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Eprestation configuration form.
 */
class EprestationConfigForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'eprestation_conf_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      Helper::SETTINGS,
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config(Helper::SETTINGS);

    $form['mail'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Mail'),
    ];

    $form['sms'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('SMS'),
    ];

    $form['mail']['subject'] = [
      '#title' => $this->t('Subject'),
      '#type' => 'textfield',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Subject'),
      ],
      '#default_value' => $config->get('subject'),
    ];

    $form['mail']['message_mail'] = [
      '#title' => $this->t('Message De confirmation demande de Calcul'),
      '#type' => 'text_format',
      '#format' => 'basic_html',
      '#description' => '[commun]<br/> [province]<br/>[nom]<br/>[nature]<br/>[metrage]<br/>[maitre_ouv]<br/>[n_rokhas]<br/>[autorisation]<br/>[declaration]',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Message E-mail'),
      ],
      '#default_value' => $config->get('message_mail')['value'] ?? '',
    ];

    $form['mail']['message_mail_final'] = [
      '#title' => $this->t('déclaration de superficie'),
      '#type' => 'text_format',
      '#format' => 'basic_html',
      '#description' => '[code] est une variable sera remplacer par le code de e-prestation',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Message E-mail'),
      ],
      '#default_value' => $config->get('message_mail_final')['value'] ?? '',
    ];

    $form['mail']['message_mail_tech'] = [
      '#title' => $this->t('Message E-mail (Rejeter)'),
      '#type' => 'text_format',
      '#format' => 'basic_html',
      '#description' => '[motif] est une variable sera remplacer par le code de e-prestation',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Message E-mail Technicien'),
      ],
      '#default_value' => $config->get('message_mail_tech')['value'] ?? '',
    ];

    $form['mail']['message_mail_compta'] = [
      '#title' => $this->t('Message E-mail Comptable'),
      '#type' => 'text_format',
      '#format' => 'basic_html',
      '#description' => '[code] est une variable sera remplacer par le code de e-prestation',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Message E-mail Comptable'),
      ],
      '#default_value' => $config->get('message_mail_compta')['value'] ?? '',
    ];

    $form['mail']['message_mail_Final_client'] = [
      '#title' => $this->t('Message E-mail Client après paiement'),
      '#type' => 'text_format',
      '#format' => 'basic_html',
      '#description' => '[code] est une variable sera remplacer par le code de e-prestation',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Message E-mail après paiement'),
      ],
      '#default_value' => $config->get('message_mail_Final_client')['value'] ?? '',
    ];

    $form['mail']['footer1'] = [
      '#title' => $this->t('Footer 1'),
      '#type' => 'textfield',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Footer 1'),
      ],
      '#default_value' => $config->get('footer1'),
    ];

    $form['mail']['footer2'] = [
      '#title' => $this->t('Footer 2'),
      '#type' => 'textfield',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Footer 2'),
      ],
      '#default_value' => $config->get('footer2'),
    ];

    $form['mail']['emailcomptable'] = [
      '#title' => $this->t('Adresse e-mail de comptable'),
      '#type' => 'email',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('E-mail'),
      ],
      '#default_value' => $config->get('emailcomptable'),
    ];

    $form['mail']['emailtechnicien'] = [
      '#title' => $this->t('Adresse e-mail de Technicien'),
      '#type' => 'email',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('E-mail'),
      ],
      '#default_value' => $config->get('emailtechnicien'),
    ];

    $form['sms']['message_phone'] = [
      '#title' => $this->t('Message De confirmation demande de Calcul (sms)'),
      '#type' => 'textarea',
      '#format' => 'basic_html',
      '#description' => '[code] est une variable sera remplacer par le code de e-prestation',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Message SMS'),
      ],
      '#default_value' => $config->get('message_phone'),
    ];

    $form['sms']['message_phone_final'] = [
      '#title' => $this->t('Message SMS Final'),
      '#type' => 'textarea',
      '#format' => 'basic_html',
      '#description' => '[code] est une variable sera remplacer par le code de e-prestation',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Message SMS'),
      ],
      '#default_value' => $config->get('message_phone_final'),
    ];

    $form['mail']['emailcci'] = [
      '#title' => $this->t('Mail en cci'),
      '#type' => 'textfield',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('mail en cci'),
      ],
      '#default_value' => $config->get('emailcci'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->configFactory->getEditable(Helper::SETTINGS)
      ->set('subject', $form_state->getValue('subject'))
      ->set('message_mail', $form_state->getValue('message_mail'))
      ->set('message_mail_final', $form_state->getValue('message_mail_final'))
      ->set('message_mail_tech', $form_state->getValue('message_mail_tech'))
      ->set('message_mail_compta', $form_state->getValue('message_mail_compta'))
      ->set('footer1', $form_state->getValue('footer1'))
      ->set('footer2', $form_state->getValue('footer2'))
      ->set('message_phone', $form_state->getValue('message_phone'))
      ->set('message_phone_final', $form_state->getValue('message_phone_final'))
      ->set('emailtechnicien', $form_state->getValue('emailtechnicien'))
      ->set('emailcomptable', $form_state->getValue('emailcomptable'))
      ->set('message_mail_Final_client', $form_state->getValue('message_mail_Final_client'))
      ->set('emailcci', $form_state->getValue('emailcci'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}
