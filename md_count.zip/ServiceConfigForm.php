<?php

namespace Drupal\md_count\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Count configuration form.
 */
class ServiceConfigForm extends FormBase {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Constructs a ServiceConfigForm object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(Connection $database) {
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'count_conf_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['service'] = [
      '#title' => $this->t('Service:'),
      '#type' => 'textfield',
      '#required' => TRUE,
      '#prefix' => '<div class="layout-column layout-column--half"><div class="panel">',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Enter service name'),
      ],
    ];

    $form['value'] = [
      '#title' => $this->t('Value:'),
      '#type' => 'number',
      '#required' => TRUE,
      '#min' => 0,
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Enter value'),
      ],
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#suffix' => '</div></div>',
      '#value' => $this->t('Insert'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = [
      'service' => $form_state->getValue('service'),
      'value' => $form_state->getValue('value'),
    ];

    try {
      $this->database->insert('md_count')
        ->fields([
          'service' => $values['service'],
          'value' => $values['value'],
        ])
        ->execute();

      $this->messenger()->addStatus($this->t('Count has been saved successfully.'));
      $form_state->setRedirect('md_count.display_table_controller_display');
    }
    catch (\Exception $e) {
      $this->messenger()->addError($this->t('An error occurred while saving: @error', ['@error' => $e->getMessage()]));
    }
  }

}
