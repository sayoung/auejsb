<?php

/**
 * @file
 * Contains \Drupal\md_count\Controller\ServiceController.
 */

namespace Drupal\md_count\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Controller for count services.
 */
class ServiceController extends ControllerBase {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Constructs a ServiceController object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(Connection $database) {
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database')
    );
  }

  /**
   * Gets services data.
   *
   * @param int $cid
   *   The count ID.
   *
   * @return array
   *   Render array.
   */
  public function getServices($cid) {
    // Select records from table.
    $query = $this->database->select('md_count', 'm');
    $query->fields('m', ['id', 'service', 'value']);
    $query->condition('id', $cid);
    $results = $query->execute()->fetchAll();

    return [
      '#theme' => 'theme_md_count_interne',
      '#count' => $results,
      '#cache' => [
        'max-age' => 0,
      ],
      '#attached' => [
        'library' => [
          'md_count/md-count-hp',
        ],
      ],
    ];
  }

}
