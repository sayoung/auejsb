# MD Count Module - File Replacement Checklist

## Files to Replace (Copy from /home/claude to your module directory)

### Root Directory Files
```
modules/md_count/
├── [ ] md_count.info.yml          (MODIFIED - core version)
├── [ ] md_count.routing.yml       (MODIFIED - permissions)
├── [ ] md_count.install           (MODIFIED - schema fix)
├── [ ] md_count.module            (NO CHANGES)
└── [ ] md_count.libraries.yml     (NO CHANGES)
```

### Controller Files
```
modules/md_count/src/Controller/
├── [ ] DisplayTableController.php     (MODIFIED - DI + Link class)
├── [ ] ServiceController.php          (MODIFIED - Fixed class name + DI)
└── [ ] MdServiceController.php        (MODIFIED - Fixed namespace)
```

### Form Files
```
modules/md_count/src/Form/
├── [ ] ServiceConfigForm.php      (MODIFIED - DI + messenger)
├── [ ] DeleteForm.php             (MODIFIED - DI + messenger)
└── [ ] UpdateForm.php             (MODIFIED - DI + messenger)
```

### Block Files
```
modules/md_count/src/Plugin/Block/
├── [ ] ServiceBlock.php           (MODIFIED - DI + ContainerFactoryPluginInterface)
└── [ ] ServiceBlockInterne.php    (MODIFIED - DI + ContainerFactoryPluginInterface)
```

### Files NOT Modified (Keep Original)
```
modules/md_count/
├── md_count.links.menu.yml
├── assets/css/style-inerne.css
├── assets/css/styles.css
├── assets/js/script.js
├── config/install/*.yml
└── templates/*.html.twig
```

## Replacement Instructions

### Option 1: Direct Copy (Recommended)
```bash
# From /home/claude directory
cp md_count.info.yml /path/to/modules/md_count/
cp md_count.routing.yml /path/to/modules/md_count/
cp md_count.install /path/to/modules/md_count/

cp DisplayTableController.php /path/to/modules/md_count/src/Controller/
cp ServiceController.php /path/to/modules/md_count/src/Controller/
cp MdServiceController.php /path/to/modules/md_count/src/Controller/

cp ServiceConfigForm.php /path/to/modules/md_count/src/Form/
cp DeleteForm.php /path/to/modules/md_count/src/Form/
cp UpdateForm.php /path/to/modules/md_count/src/Form/

cp ServiceBlock.php /path/to/modules/md_count/src/Plugin/Block/
cp ServiceBlockInterne.php /path/to/modules/md_count/src/Plugin/Block/

# Clear cache
drush cr
```

### Option 2: Manual Replacement
1. Back up your existing module
2. Replace each file individually
3. Compare changes if needed
4. Clear Drupal cache

## Quick Verification

After replacement, verify these key changes:

### md_count.info.yml
```yaml
core_version_requirement: ^10.2 || ^11  # Should see this
```

### Any Form File (check one)
```php
// Should see dependency injection
protected $database;

public function __construct(Connection $database) {
  $this->database = $database;
}

// Should see messenger instead of drupal_set_message
$this->messenger()->addStatus($this->t('Success'));
```

### DisplayTableController.php
```php
// Should NOT see \Drupal::l()
// Should see operations render element
'operations' => [
  'data' => [
    '#type' => 'operations',
    '#links' => [...]
  ]
]
```

## Post-Replacement Steps

1. [ ] Clear Drupal cache: `drush cr`
2. [ ] Check for errors: `drush watchdog:show`
3. [ ] Test admin interface: `/admin/config/count/list`
4. [ ] Test CRUD operations
5. [ ] Verify blocks render
6. [ ] Check front-end display

## Rollback (If Needed)

```bash
# Restore from backup
cp -r modules/custom/md_count.backup/* modules/custom/md_count/
drush cr
```

## Key Changes Summary

| Component | Old Method | New Method |
|-----------|-----------|------------|
| Database | `db_insert()` | `$this->database->insert()` |
| Messages | `drupal_set_message()` | `$this->messenger()->addStatus()` |
| Links | `\Drupal::l()` | Operations render element |
| Permissions | `_access: 'TRUE'` | `_permission: 'administer site configuration'` |
| DI | None | All classes use constructor injection |

## Files Generated

All upgraded files are in: `/home/claude/`

- Configuration: 3 files
- Controllers: 3 files  
- Forms: 3 files
- Blocks: 2 files
- Documentation: 2 files

**Total: 13 files ready for deployment**
