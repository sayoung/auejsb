<?php

namespace Drupal\md_count\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'ServiceBlock' block.
 *
 * @Block(
 *  id = "md_count_block",
 *  admin_label = @Translation("Count Block"),
 * )
 */
class ServiceBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Constructs a ServiceBlock object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, Connection $database) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('database')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    // Select records from table.
    $query = $this->database->select('md_count', 'm');
    $query->fields('m', ['id', 'service', 'value']);
    $results = $query->execute()->fetchAll();

    return [
      '#theme' => 'theme_md_count',
      '#count' => $results,
      '#cache' => [
        'max-age' => 0,
      ],
      '#attached' => [
        'library' => [
          'md_count/md-count-hp',
        ],
      ],
    ];
  }

}
