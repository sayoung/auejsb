<?php

namespace Drupal\md_count\Form;

use Drupal\Core\Form\ConfirmFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Database\Connection;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a form for updating a count record.
 *
 * @package Drupal\md_count\Form
 */
class UpdateForm extends ConfirmFormBase {

  /**
   * The database connection.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * The count ID.
   *
   * @var int
   */
  protected $cid;

  /**
   * Constructs an UpdateForm object.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(Connection $database) {
    $this->database = $database;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('database')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'Update_Form';
  }

  /**
   * {@inheritdoc}
   */
  public function getQuestion() {
    return $this->t('Update count record %cid?', ['%cid' => $this->cid]);
  }

  /**
   * {@inheritdoc}
   */
  public function getCancelUrl() {
    return new Url('md_count.display_table_controller_display');
  }

  /**
   * {@inheritdoc}
   */
  public function getDescription() {
    return $this->t('Update the count information below.');
  }

  /**
   * {@inheritdoc}
   */
  public function getConfirmText() {
    return $this->t('Update');
  }

  /**
   * {@inheritdoc}
   */
  public function getCancelText() {
    return $this->t('Cancel');
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, $cid = NULL) {
    $this->cid = $cid;

    // Select records from table.
    $query = $this->database->select('md_count', 'm');
    $query->fields('m', ['id', 'service', 'value']);
    $query->condition('id', $this->cid);
    $results = $query->execute()->fetchAssoc();

    if (!$results) {
      $this->messenger()->addError($this->t('Count record not found.'));
      $form_state->setRedirect('md_count.display_table_controller_display');
      return [];
    }

    $form['service'] = [
      '#title' => $this->t('Service:'),
      '#type' => 'textfield',
      '#required' => TRUE,
      '#prefix' => '<div class="layout-column layout-column--half"><div class="panel">',
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Enter service name'),
      ],
      '#default_value' => $results['service'],
    ];

    $form['value'] = [
      '#title' => $this->t('Value:'),
      '#type' => 'number',
      '#required' => TRUE,
      '#min' => 0,
      '#attributes' => [
        'class' => ['text-input', 'mauticform-input'],
        'placeholder' => $this->t('Enter value'),
      ],
      '#default_value' => $results['value'],
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#suffix' => '</div></div>',
      '#value' => $this->t('Update'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = [
      'service' => $form_state->getValue('service'),
      'value' => $form_state->getValue('value'),
    ];

    try {
      $this->database->update('md_count')
        ->fields([
          'service' => $values['service'],
          'value' => $values['value'],
        ])
        ->condition('id', $this->cid)
        ->execute();

      $this->messenger()->addStatus($this->t('Count has been updated successfully.'));
    }
    catch (\Exception $e) {
      $this->messenger()->addError($this->t('An error occurred while updating: @error', ['@error' => $e->getMessage()]));
    }

    $form_state->setRedirect('md_count.display_table_controller_display');
  }

}
